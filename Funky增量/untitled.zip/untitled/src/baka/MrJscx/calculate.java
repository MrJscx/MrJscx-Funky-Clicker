package baka.MrJscx;

public class calculate {
    public static float sum(float a, float b) {
        return a+b;
    }

    public static float difference(float a, float b) {
        return a-b;
    }

    public static float product(float a, float b) {
        return a*b;
    }
    public static float quotient(float a, float b) {
        return a/b;
    }
}