//TIP 要<b>运行</b>代码，请按 <shortcut actionId="Run"/> 或
// 点击装订区域中的 <icon src="AllIcons.Actions.Execute"/> 图标。
package baka.MrJscx;

public class Main {
    public static void main(String[] args) {

        class Ladder{
            float above;
            float bottom;
            float height;
            float area;
            float computerArea(){
                area = (above + bottom) * height/2.0f;//这个注释没有什么太大的用，单纯是为了完成任务来写的
                return area;
            }
        }

        class Mark{
            float Chinese;
            float Mathematics;
            float English;
        }

        System.out.println("hi");

        Ladder funky1;
        funky1 = new Ladder();
        funky1.above=114;
        funky1.bottom=514;
        funky1.height=1919;
        System.out.println("在funky1类中，area的值为"+funky1.computerArea() );

        Ladder funky2 = new Ladder();
        funky2.above=10;
        funky2.bottom=20;
        funky2.height=40;
        System.out.println("在funky2类中，area的值为"+funky2.computerArea() );
        funky2.height=114514;
        System.out.println("在funky2类中，height的值现为"+funky2.height );
        System.out.println("在funky1类中，height的值现为"+funky1.height );


        System.out.println("咱们来进行一个小测试");
        System.out.println("26+14=" + calculate.sum(26,14));
        System.out.println("40-16=" + calculate.difference(40,16));
        System.out.println("15*48=" + calculate.product(15,48));
        System.out.println("1919810/114=" + calculate.quotient(1919810,114));

        Mark Crino = new Mark();
        Crino.Chinese=20;
        Crino.Mathematics=9;
        Crino.English=10;
        System.out.println("大baka的分数为");
        System.out.println("语文:" + Crino.Chinese);
        System.out.println("数学:" + Crino.Mathematics);
        System.out.println("英语:" + Crino.English);
        System.out.println("总分为：" + (Crino.Chinese+Crino.Mathematics+Crino.English));
    }
}