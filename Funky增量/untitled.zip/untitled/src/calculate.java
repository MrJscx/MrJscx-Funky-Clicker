public class calculate {
    public static float sum(int a, int b) {
        return a+b;
    }

    public static float difference(int a, int b) {
        return a-b;
    }

    public static float product(int a, int b) {
        return a*b;
    }
    public static float quotient(int a, int b) {
        int i = a / b;
        return i;
    }
}